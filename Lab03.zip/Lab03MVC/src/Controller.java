

// This is a dummy Controller, so the View compiles
public class Controller {
}
