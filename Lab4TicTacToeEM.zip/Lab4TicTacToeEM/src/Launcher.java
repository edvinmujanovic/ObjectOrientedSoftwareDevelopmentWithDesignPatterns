public class Launcher {
    public static void main(String[] args) { //skapa ny kontroller o kör, starta gamet.
            Controller gameController = new Controller(); 
            gameController.startGame(); //metod från klassen Controller som körs
    };
}
